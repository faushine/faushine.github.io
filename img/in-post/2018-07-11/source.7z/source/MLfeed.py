import matplotlib.pyplot as plt
from matplotlib.ticker import MultipleLocator
feed_dir = 'D:\\'
feed = 'MSHYBFND'
feed_name_1 = feed+'.18.02.txt'
feed_name_2 = feed+'.18.03.txt'
feed_name_3 = feed+'.18.04.txt'
feed_name_4 = feed+'.18.05.txt'
feed_name_5 = feed+'.18.06.txt'


file_1 = feed_dir+'\\'+feed_name_1
file_2 = feed_dir+'\\'+feed_name_2
file_3 = feed_dir+'\\'+feed_name_3
file_4 = feed_dir+'\\'+feed_name_4
file_5 = feed_dir+'\\'+feed_name_5


feed_name = feed+' '+feed_name_1.split('.')[2]+' - '+feed_name_5.split('.')[2] +' Beta'
yild = 9
beta = 11
yild_num = 100
beta_num = 100

type = beta
type_num = beta_num

def openFile(path, type):
    map = {}
    list = []
    with open(path,encoding='utf-8',mode = 'r') as file:
        while 1:
            line = file.readline()
            column = line.split('~')
            if(len(column)>3):
                if(column[7] is not '' and column[type] is not ''):
                    map[column[7]] = column[type]
                    list.append(column[7])
            if not line:
                map['total'] = list
                return map

def getDiff(feed_1,feed_2):
    return abs((feed_2-feed_1)/feed_1)

def getResult(file_1, file_2, type):
    diff_value = []
    feed_map_1 = openFile(file_1, type)
    key_1 = feed_map_1['total']
    feed_map_2 = openFile(file_2, type)
    key_2 = feed_map_2['total']
    keys_beta = list(set(key_1).intersection(set(key_2)))
    del feed_map_1['total']
    del feed_map_2['total']

    for key in keys_beta:
        value_1 = float(feed_map_1[key])
        value_2 = float(feed_map_2[key])
        if abs(value_1) != 0.0 and abs(value_1 - value_2)>0.0:
            diff = abs(getDiff(value_1, value_2))
            if diff <= 1:
                diff_value.append(diff)
    return diff_value


if __name__ == '__main__':
    diff_value_1 = getResult(file_1,file_2, type)
    diff_value_2 = getResult(file_2,file_3, type)
    diff_value_3 = getResult(file_3,file_4, type)
    diff_value_4 = getResult(file_4,file_5, type)


    print(len(diff_value_1))
    print(len(diff_value_2))
    print(len(diff_value_3))
    print(len(diff_value_4))


    plt.figure(figsize=(12,6))
    (counts,bins,patch) = plt.hist([diff_value_1,diff_value_2,diff_value_3,diff_value_4],bins=20,color=['green','blue','red','yellow'], alpha=0.5,label=('02-03', '03-04','04-05','05-06'))

    plt.xlim(0,1)
    ax = plt.gca()
    ax.yaxis.set_major_locator(MultipleLocator(type_num))
    ax.yaxis.set_minor_locator(MultipleLocator(type_num/2))
    ax.xaxis.set_major_locator(MultipleLocator(0.1))
    ax.xaxis.set_minor_locator(MultipleLocator(0.05))
    plt.xlabel('Different value exist(%)')
    plt.ylabel('Count')
    plt.title(feed_name)
    plt.grid()
    plt.legend()

    j=4
    total_1 = counts[0][0]+counts[0][1]+counts[0][2]+counts[0][3]
    total_1 = total_1+counts[1][0]+counts[1][1]+counts[1][2]+counts[1][3]
    total_1 = total_1+counts[2][0]+counts[2][1]+counts[2][2]+counts[2][3]
    total_1 = total_1+counts[3][0]+counts[3][1]+counts[3][2]+counts[3][3]
    diff_total_1 = len(diff_value_1)+len(diff_value_2)+len(diff_value_3)+len(diff_value_4)
    for t in range(2,6):
        for i in range(0,4):
            total_1 = total_1+counts[i][j]+counts[i][j+1]+counts[i][j+2]+counts[i][j+3]
        plt.annotate(str(round(total_1/diff_total_1*100,1))+'%', xy=(0.2*t, 0), xytext=(0.2*t, type_num), arrowprops={'arrowstyle': '->'})
        j = j+4

    total = 0
    diff_total = len(diff_value_1) + len(diff_value_2) + len(diff_value_3) + len(diff_value_4)
    for t in range(0, 4):
        for i in range(0, 4):
            total = total + counts[i][t];
        plt.annotate(str(round(total / diff_total * 100, 1)) + '%', xy=(0.05 * (t+1), 0), xytext=(0.05 * (t+1), type_num),
                     arrowprops={'arrowstyle': '->'})

    plt.savefig(feed_name+'.png')
    plt.show()




